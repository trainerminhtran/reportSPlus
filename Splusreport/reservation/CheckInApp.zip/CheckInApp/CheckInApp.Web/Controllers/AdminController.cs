﻿using CheckInApp.Data.Models;
using CheckInApp.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CheckInApp.Web.Controllers
{
    [Authorize]
    public class AdminController : Controller
    {
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly CheckInAppContext _context;
        public AdminController(CheckInAppContext context, UserManager<IdentityUser> userManager, SignInManager<IdentityUser> signInManager)
        {
            _context = context;
            _userManager = userManager;
            _signInManager = signInManager;
        }
        [AllowAnonymous]
        public IActionResult Login()
        {
            return View();
        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Login(LoginModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return View();
                }
                var user = await _userManager.FindByNameAsync(model.UserName);
                if (user != null)
                {
                    var login = await _signInManager.PasswordSignInAsync(user, model.Password, model.RememberMe, true);
                    if (login.Succeeded)
                    {
                        return Redirect("/Admin/Sessions");
                    }
                    else
                    {
                        ModelState.AddModelError(string.Empty, "Mật khẩu không chính xác");
                    }
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Tài khoản không tồn tại");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, "Lỗi hệ thống! Vui lòng liên hệ Admin");
            }
            return View();
        }
        public IActionResult ChangePassword()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> ChangePassword(ChangePasswordModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return View();
                }
                var currentUser = await _userManager.GetUserAsync(User);
                if (currentUser != null)
                {
                    var checkSuccess = await _userManager.CheckPasswordAsync(currentUser, model.OldPassword);
                    if(!checkSuccess)
                    {
                        ModelState.AddModelError(string.Empty, "Mật khẩu cũ không đúng");
                    }
                    else
                    {
                        var changePassword = await _userManager.ChangePasswordAsync(currentUser, model.OldPassword, model.NewPassword);
                        if (changePassword.Succeeded)
                        {
                            ViewBag.Message = "Đổi mật khẩu thành công";
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Đổi mật khẩu thất bại");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, "Lỗi Hệ thống, Vui lòng liên hệ Admin");
            }
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> DeleteSession(int id)
        {
            var session = await _context.Sessions.FindAsync(id);
            if (session != null)
            {
                _context.Sessions.Remove(session);

                var bookings = await _context.Bookings.Where(i => i.SessionId == id).ToListAsync();
                if (bookings.Any())
                {
                    foreach (var booking in bookings)
                    {
                        booking.SessionId = null;
                    }
                }
                var groups = await _context.GroupSessions.Where(i => i.SessionId == id).ToListAsync();
                if (groups.Any())
                {
                    foreach (var group in groups)
                    {
                        group.SessionId = null;
                    }
                }

                await _context.SaveChangesAsync();
            }
            return Redirect("/Admin/Sessions");
        }
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return Redirect("/Admin/Login");
        }
        public async Task<IActionResult> Bookings(int page = 1)
        {
            var result = new ResultDTO<Bookings>()
            {
                Page = page,
                TotalPage = (int)Math.Ceiling((double)await _context.Bookings.CountAsync() / 20),
                Items = await _context.Bookings.OrderByDescending(o => o.Created).Skip((page - 1) * 20).Take(20)
                                    .Include(i=> i.Session)
                                    .Include(i => i.Group)
                                    .Include(i => i.Shop)
                                    .AsNoTracking().ToListAsync(),
            };
            return View(result);
        }
        [HttpPost]
        public async Task<IActionResult> DeleteBooking(int id)
        {
            var booking = await _context.Bookings.FindAsync(id);
            if (booking != null)
            {
                _context.Bookings.Remove(booking);
                await _context.SaveChangesAsync(); ;
            }
            return Redirect("/Admin/Bookings");
        }
        public async Task<IActionResult> Sessions(int page = 1)
        {
            var result = new ResultDTO<Sessions>()
            {
                Page = page,
                TotalPage = (int)Math.Ceiling((double)await _context.Sessions.CountAsync() / 20),
                Items = await _context.Sessions.OrderBy(o => o.Date).Skip((page - 1) * 20).Take(20).AsNoTracking().ToListAsync(),
            };
            return View(result);
        }
        public IActionResult SeesionAction(int id = 0)
        {
            ViewBag.Id = id;
            return View();
        }


    }
}
