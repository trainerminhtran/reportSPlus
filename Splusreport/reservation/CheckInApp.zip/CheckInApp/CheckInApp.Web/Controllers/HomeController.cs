﻿using CheckInApp.Data.Models;
using CheckInApp.Web.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace CheckInApp.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly CheckInAppContext _context;

        public HomeController(CheckInAppContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(string provinceCode, string groupCode)
        {
            var router = new Router() { IsNotFound = true };
            if (!String.IsNullOrEmpty(provinceCode) && !String.IsNullOrEmpty(groupCode))
            {
                if (await _context.Provinces.AnyAsync(i => i.Code == provinceCode) && await _context.Groups.AnyAsync(i => i.Code == groupCode))
                {
                    router.IsNotFound = false;
                    router.ProvinceCode = provinceCode;
                    router.GroupCode = groupCode;
                }
            }
            return View(router);
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult NotFound()
        {
            return View();
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
