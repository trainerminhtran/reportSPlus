﻿using CheckInApp.Data.Models;
using CheckInApp.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CheckInApp.Web.Controllers
{
    [Route("api/")]
    public class CheckInController : ControllerBase
    {
        private readonly CheckInAppContext _context;
        public CheckInController(CheckInAppContext context)
        {
            _context = context;
        }
        [HttpGet("sessions")]
        public async Task<IActionResult> GetSessions(SessionArg args)
        {
            try
            {
                var sessions = await _context.Sessions.Where(x => x.Province.Code == args.Province
                && (String.IsNullOrEmpty(args.EmployeeCode) || x.Bookings.Any(i => i.EmployeeCode == args.EmployeeCode.Trim()))
                && (args.StoreId == 0 || x.Bookings.Any(i => i.Shop.Id == args.StoreId))
                && x.GroupSessions.Any(i => i.Group.Code == args.Group)
                && x.Date >= DateTime.Now.Date).Include(i => i.Bookings).Include(i => i.GroupSessions).AsNoTracking().ToListAsync();
                if (!sessions.Any())
                    return NoContent();
                var group = await _context.Groups.FirstOrDefaultAsync(i => i.Code == args.Group);
                var items = sessions.GroupBy(o => o.Date).Select(s => new SessionViewModel()
                {
                    Date = s.Key,
                    Data = s.Select(detail => new SessionDetailViewModel()
                    {
                        Id = detail.Id,
                        GroupId = group?.Id,
                        Name = detail.Name,
                        TotalAvailable = detail.Capacity.Value,
                        Time = detail.Time,
                        StartTime = detail.StartTime,
                        EndTime = detail.EndTime,
                        Status = detail.Capacity.Value == 0 ? "full" : "available",
                        Prize = detail.GroupSessions.FirstOrDefault(i => i.GroupId == group.Id)?.Prize,
                        Address = detail.GroupSessions.FirstOrDefault(i => i.GroupId == group.Id)?.Address,
                        LinkGroup = detail.GroupSessions.FirstOrDefault(i => i.GroupId == group.Id)?.LinkGroup,
                        Employees = detail.Bookings.Where(k => String.IsNullOrEmpty(args.EmployeeCode) || k.EmployeeCode == args.EmployeeCode.Trim()).Select(e => new EmployeeViewModel()
                        {
                            Code = e.EmployeeCode,
                            Name = e.EmployeeName,
                            CreatedDate = e.Created.Value
                        }).OrderByDescending(o => o.CreatedDate)
                    }).OrderBy(o => o.Time),

                }).OrderBy(o => o.Date);
                return Ok(items);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("report")]
        public async Task<IActionResult> GetReport(SessionArg args)
        {
            try
            {
                var report = new ReportViewModel();
                var bookings = await _context.Bookings.Where(x => (args.StoreId == 0 || x.Shop.Id == args.StoreId)
                                                            && (String.IsNullOrEmpty(args.EmployeeCode) || args.EmployeeCode.Trim() == x.EmployeeCode)
                                                            && (x.Group.Code == args.Group) && (x.Session != null && x.Session.Province.Code == args.Province))
                                                            .Include(i => i.Shop)
                                                            .Include(i => i.Group)
                                                            .Include(i => i.Session)
                                                                .AsNoTracking().ToListAsync();
                if (bookings.Any())
                {
                    report.TotalEmployee = bookings.GroupBy(g => g.EmployeeCode).Count();
                    report.TotalShop = bookings.GroupBy(g => g.ShopId).Count();
                    report.Data = bookings.Select(s => new ExportDataViewModel()
                    {
                        EmployeeCode = s.EmployeeCode,
                        EmployeeName = s.EmployeeName,
                        Shop = s.Shop?.Name.Replace(",", "."),
                        CreatedDate = s.Created.Value.ToString("dd/MM/yyyy"),
                        GroupCode = s.Group?.Code,
                        Province = args.Province?.ToUpper(),
                        SessionName = s.Session?.Name,
                        SessionDate = s.Session.Date.ToString("dd/MM/yyyy"),
                    });
                }
                return Ok(report);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("shops")]
        public async Task<IActionResult> GetShops()
        {
            var model = await _context.Shops.Select(s => new { Id = s.Id, Name = s.Name }).AsNoTracking().ToListAsync();
            return Ok(model);
        }
        [HttpGet("groups")]
        public async Task<IActionResult> GetGroups()
        {
            var groups = await _context.Groups.Select(s => new { Id = s.Id, Name = s.Name }).AsNoTracking().ToListAsync();
            return Ok(groups);
        }
        [Authorize]
        [HttpPost("handle-session")]
        public async Task<IActionResult> HandleSessions([FromBody] SessionModel model)
        {
            var result = new ResultDTO();
            try
            {
                model.Session.Date = model.Session.Date.ToLocalTime();
                switch (model.Type)
                {
                    case "detail":
                        {
                            if (model.Session != null && model.Session.Id != 0)
                            {
                                result.Items = await _context.Sessions.Include(i => i.GroupSessions).FirstOrDefaultAsync(x => x.Id == model.Session.Id);
                            }
                            break;
                        }
                    case "update":
                        {
                            var groups = await _context.GroupSessions.Where(i => i.SessionId == model.Session.Id).ToListAsync();
                            _context.GroupSessions.RemoveRange(groups);

                            _context.Sessions.Update(model.Session);
                            foreach (var group in model.GroupSessions)
                            {
                                group.Id = 0;
                                group.SessionId = model.Session.Id;
                            }
                            _context.GroupSessions.AddRange(model.GroupSessions);
                            break;
                        }
                    case "insert":
                        {
                            model.Session.GroupSessions = model.GroupSessions;
                            _context.Sessions.Add(model.Session);
                            break;
                        }
                }
                if (model.Type != "detail")
                    await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                result.ErrorMessage = "Lỗi hệ thống. vui lòng liên hệ Admin";
            }

            return Ok(result);

        }
        [HttpPost("booking")]
        public async Task<int> SaveBooking([FromBody] Bookings model)
        {
            model.EmployeeCode = model.EmployeeCode?.Trim();
            model.EmployeeName = model.EmployeeName?.Trim();
            var isDuplicate = await _context.Bookings.AnyAsync(i => i.SessionId == model.SessionId && i.EmployeeCode == model.EmployeeCode);
            if (isDuplicate)
            {
                return -1;
            }
            var isFull = await _context.Sessions.AnyAsync(i => i.Id == model.SessionId && i.Capacity == 0);
            if (isFull)
            {
                return -2;
            }
            model.Created = DateTime.Now;
            await _context.Bookings.AddAsync(model);

            var session = await _context.Sessions.FindAsync(model.SessionId);
            if (session != null)
            {
                session.Capacity = session.Capacity - 1;
            }
            return await _context.SaveChangesAsync();
        }
        public class SessionModel
        {
            public SessionModel()
            {
                Session = new Sessions();
                GroupSessions = new List<GroupSessions>();
            }
            public string Type { get; set; }
            public Sessions Session { get; set; }
            public List<GroupSessions> GroupSessions { get; set; }
        }
    }
}
