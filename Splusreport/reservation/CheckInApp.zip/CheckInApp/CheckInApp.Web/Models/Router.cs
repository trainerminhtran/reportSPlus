﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CheckInApp.Web.Models
{
    public class Router
    {
        public bool IsNotFound { get; set; }
        public string ProvinceCode { get; set; }
        public string GroupCode { get; set; }
    }
}
