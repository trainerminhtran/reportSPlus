﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CheckInApp.Web.Models
{
    public class ResultDTO<T>
    {
        public int Page { get; set; }
        public int TotalPage { get; set; }
        public List<T> Items { get; set; }
    }
    public class ResultDTO
    {
        public string ErrorMessage { get; set; }
        public object Items { get; set; }
    }
    public class SessionArg
    {
        public string Province { get; set; }
        public string Group { get; set; }
        public int StoreId { get; set; }
        public string EmployeeCode { get; set; }
    }
}
