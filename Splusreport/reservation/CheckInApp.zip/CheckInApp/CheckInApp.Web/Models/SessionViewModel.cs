﻿using CheckInApp.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CheckInApp.Web.Models
{
    public class ReportViewModel
    {
        public ReportViewModel()
        {
            Data = new List<ExportDataViewModel>();
        }
        public int TotalEmployee { get; set; }
        public int TotalShop { get; set; }
        public IEnumerable<ExportDataViewModel> Data { get; set; }
    }
    public class ExportDataViewModel
    {
        public string EmployeeCode { get; set; }
        public string EmployeeName { get; set; }
        public string Shop { get; set; }
        public string Province { get; set; }
        public string GroupCode { get; set; }
        public string SessionName { get; set; }
        public string SessionDate { get; set; }
        public string CreatedDate { get; set; }

    }
    public class SessionViewModel
    {
        public SessionViewModel()
        {
            Data = new List<SessionDetailViewModel>();
        }
        public DateTime Date { get; set; }
        public IEnumerable<SessionDetailViewModel> Data { get; set; }
    }
    public class SessionDetailViewModel
    {
        public int Id { get; set; }
        public int? GroupId { get; set; }
        public string Name { get; set; }
        public string Time { get; set; }
        public string Status { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public string Prize { get; set; }
        public string Address { get; set; }
        public string LinkGroup { get; set; }
        public int TotalAvailable { get; set; }
        public IEnumerable<EmployeeViewModel> Employees { get; set; }
    }
    public class EmployeeViewModel
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
