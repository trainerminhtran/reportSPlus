﻿var app = angular.module('checkInApp', ["ngJsonExportExcel","loading"]);
app.controller('CheckInAppController', function ($rootScope, $scope, checkInService, $timeout, $http) {
    $scope.onInit = async function (province, group) {
        $scope.shops = [];
        $scope.isFilter = false;
        $scope.exportField = { employeeCode: 'Mã nhân viên', employeeName: 'Tên nhân viên', groupCode: 'Account', shop: 'Nơi làm việc', province: 'City', sessionName: 'Tên buổi', sessionDate: 'Ngày diễn ra', createdDate: 'Ngày đăng ký' }
        $scope.params = {
            province: province,
            group: group,
            storeId: '',
            employeeCode: ''
        }
        $scope.query = { employeeCode: '' };
        await getSession();
        await getReport();
        await getShops();
    }
    $timeout(function () {
        $('.sel').select2();
    }, 0);
    async function getSession() {
        var res = await checkInService.getSession($scope.params);
        if (res) {
            $timeout(function () {
                $scope.model = res.data;
            }, 0);
        }
    }
    async function getShops() {
        let shops = await checkInService.getShops();
        $timeout(function () {
            $scope.shops = shops.data;
        }, 0);
    }
    async function getReport() {
        let report = await checkInService.getReport($scope.params);
        $timeout(function () {
            $scope.report = report.data;
        }, 0);
    }

    this.openModel = async function (item) {
        $scope.detail = item;
        this.isError = false; 
        if ($scope.isFilter && item.employees.length > 0) {
            $scope.modalTitle = `Danh sách đặt chỗ ${item.name}`;
            this.stepButton = item.status == 'full' ? null : 'Đặt chỗ';
            this.step = "reservation";
        }
        else {
            if (item.status == 'full')
                return false;
            $scope.modalTitle = "Thông tin đặt chỗ";
            $timeout(function () {
                $(".sel").select2();
            }, 0);
            this.stepButton = "Tiếp tục";
            this.step = "information";
        }
        $("#bookingModal").modal();
        $scope.info = {
            "employeeCode": '',
            "employeeName": '',
            "shopId": 0,
            "groupId": item.groupId,
            "sessionId": item.id
        };
        $scope.linkGroup = item.linkGroup;
    }
    $scope.getkeys = async function (event) {
        if (event.keyCode == 13) {
            await filter();
        }
    }
    $scope.exportExcel = async function () {
        $timeout(function () {
            document.getElementById('btnExport').click();
        }, 0);

    }
    this.filter = async function () {
        await filter();
    }
    this.reset = async function () {
        $scope.query.employeeCode = '';
        $('#search-store-select2').val('0').trigger('change');
        await filter();
    }
    async function filter() {
        let storeId = Number(document.getElementById("search-store-select2").value);
        $scope.isFilter = storeId != 0 || $scope.query.employeeCode;
        $scope.params.storeId = storeId;
        $scope.params.employeeCode = $scope.query.employeeCode;
        await getSession();
        await getReport();
    }
    this.save = async function () {
        this.isError = false;
        switch (this.step) {
            case "reservation": {
                $timeout(function () {
                    $(".sel").select2();
                }, 0);
                $scope.modalTitle = "Thông tin đặt chỗ";
                this.stepButton = "Tiếp tục";
                this.step = "information";
                break;
            }
            case "information": {
                $scope.info.shopId = Number(document.getElementById("shop-select2").value);
                this.isError = !$scope.info.employeeCode || !$scope.info.employeeName || $scope.info.shopId == 0;
                if (!this.isError) {
                    this.stepButton = "Xác nhận đặt chỗ";
                    this.step = "confirmation";
                } else {
                    this.errorMessage = "Vui lòng điền đầy đủ thông tin"
                }
                break;
            }
            case "confirmation": {
              
                let save = await checkInService.saveBooking($scope.info);
                if (save.data == -1) {
                    this.isError = true;
                    this.errorMessage = "Bạn đã đăng ký buổi này";
                }
                else if (save.data == -2) {
                    this.isError = true;
                    this.errorMessage = "Phòng này đã hết chỗ";
                    await getSession();
                } else {
                    let shopName = $scope.shops.find(i => i.id === $scope.info.shopId).name;
                    $scope.detail = { ...$scope.detail, 'shopName': shopName }
                    this.stepButton = "Đóng";
                    this.step = "success";
                }
                $scope.$applyAsync();
                break;
            }
            case "success": {
                await getSession();
                await getReport();
                $("#bookingModal").modal("hide");
                break;
            }
        }
    }

});