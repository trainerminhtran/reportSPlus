﻿
(function () {
    "use strict";
    angular.module('checkInApp').factory('checkInService', function ($http) {
        var service = {
            getSession: function (args) {
                return $http({
                    url: `/api/sessions`,
                    method: "GET",
                    params: args
                });
            },
            getShops: function () {
                return $http({
                    url: `/api/shops`,
                    method: "GET",
                });
            },
            getGroups: function () {
                return $http({
                    url: `/api/groups`,
                    method: "GET",
                });
            },
            saveBooking: function (model) {
                return $http.post('/api/booking', model);
            },
            getReport: function (args) {
                return $http({
                    url: `/api/report`,
                    method: "GET",
                    params: args
                });
            },
        };
        return service;
    });
})();
