﻿angular.module('loading', [])

    .directive('loading', ['$http', function ($http) {
        return {
            restrict: 'A',
            link: function (scope) {
                scope.isLoading = function () {
                    return $http.pendingRequests.length > 0;
                };
                scope.$watch(scope.isLoading, function (v) {
                    if (v) {
                        $("#loading").show();
                    } else {
                        $("#loading").hide();
                    }
                });
            }
        };

    }]);