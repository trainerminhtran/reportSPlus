﻿var app = angular.module('adminApp', []);
app.controller('AdminController', function ($rootScope, $scope, $timeout, adminService) {
    $scope.onInit = async function (id) {
        $scope.errors = [];
        $scope.model = {
            provinceId: 1,
            time: 'AM',
            capacity: 35,
            startTime: "09:30",
            endTime: '12:00',
            groupSessions: [{"id": 0,"groupId": 0, "linkGroup": '', "address": '', "prize": '' }],
        };
        $scope.provices = [
            { 'id': 1, 'name': 'Hồ Chí Minh' },
            { 'id': 2, 'name': 'Hà Nội' },
        ]
        await getGroups();
        if (id == 0) {
        } else {
            $scope.model.id = id;
            var detail = await handleSession("detail");
            $timeout(function () {
                $scope.model = detail.items;
                $scope.model.date = new Date(detail.items.date);
            }, 0);
        }
    }
    async function getGroups() {
        let shops = await adminService.getGroups();
        $timeout(function () {
            $scope.groups = shops.data;
        }, 0);
    }
    this.addRow = function () {
        $scope.model.groupSessions.push({ "groupId": '0', "linkGroup": '', "address": '', "prize": '' });
    }
    this.removeRow = function (index) {
        $scope.model.groupSessions.splice(index, 1);
    }
    this.save = async function () {
        $scope.errors = validate($scope.model);
        if ($scope.errors.length > 0) {
            $scope.$applyAsync();
            return false;
        }
        let type = $scope.model.id ? "update" : "insert";
        var res = await handleSession(type);
        if (res.errorMessage) {
            $scope.errors.push(res.errorMessage);
            $scope.$applyAsync();
        } else {
            let message = type == 'update' ? "Cập nhật" : "Thêm mới";
            window.toastr.success(message + " thành công");
        }
    }
    function omit(key, obj) {
        const { [key]: omitted, ...rest } = obj;
        return rest;
    }
    async function handleSession(type) {
        const model = {
            type: type,
            session: omit('groupSessions',$scope.model),
            groupSessions: $scope.model.groupSessions
        }
        var result = await adminService.handleSession(model);
        return result.data;
    }
    this.handleTime = function () {
        if ($scope.model.time == 'AM') {
            $scope.model.startTime = '09:30';
            $scope.model.endTime = '12:00';
        } else {
            $scope.model.startTime = '13:30';
            $scope.model.endTime = '16:00';
        }
    }
    function validate(item) {
        const errors = [];
        if (!item.name) {
            errors.push("Vui lòng nhập tên buổi");
        }
        if (!item.date) {
            errors.push("Vui lòng nhập ngày diễn ra");
        }
        if (item.groupSessions.find(i => i.groupId == 0)) {
            errors.push("Vui lòng chọn chanel group");
        }
        for (const group of item.groupSessions) {
            if (item.groupSessions.filter(i => group.groupId != 0 && i.groupId == group.groupId).length > 1) {
                errors.push("Chanel group không được trùng nhau");
                break;
            }
        }
        return errors;
    }
});
app.factory('adminService', function ($http) {
    var service = {
        getGroups: function () {
            return $http({
                url: `/api/groups`,
                method: "GET",
            });
        },
        handleSession: function (model) {
            return $http.post('/api/handle-session', model);
        },
    };
    return service;
});