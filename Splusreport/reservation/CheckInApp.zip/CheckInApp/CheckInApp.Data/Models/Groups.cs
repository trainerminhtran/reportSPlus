﻿using System;
using System.Collections.Generic;

namespace CheckInApp.Data.Models
{
    public partial class Groups
    {
        public Groups()
        {
            GroupSessions = new HashSet<GroupSessions>();
            Shops = new HashSet<Shops>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }

        public virtual ICollection<GroupSessions> GroupSessions { get; set; }
        public virtual ICollection<Shops> Shops { get; set; }
        public virtual ICollection<Bookings> Bookings { get; set; }
    }
}
