﻿using System;
using System.Collections.Generic;

namespace CheckInApp.Data.Models
{
    public partial class Provinces
    {
        public Provinces()
        {
            Sessions = new HashSet<Sessions>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }

        public virtual ICollection<Sessions> Sessions { get; set; }
    }
}
