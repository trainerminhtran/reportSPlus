﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace CheckInApp.Data.Models
{
    public partial class Sessions
    {
        public Sessions()
        {
            Bookings = new HashSet<Bookings>();
            GroupSessions = new HashSet<GroupSessions>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime Date { get; set; }
        public string Time { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public int? Capacity { get; set; }
        public int? ProvinceId { get; set; }

        public virtual Provinces Province { get; set; }
        public virtual ICollection<Bookings> Bookings { get; set; }
        public virtual ICollection<GroupSessions> GroupSessions { get; set; }
    }
}
