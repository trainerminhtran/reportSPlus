﻿using System;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CheckInApp.Data.Models
{
    public partial class CheckInAppContext : IdentityDbContext
    {
        public CheckInAppContext()
        {
        }

        public CheckInAppContext(DbContextOptions<CheckInAppContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Bookings> Bookings { get; set; }
        public virtual DbSet<GroupSessions> GroupSessions { get; set; }
        public virtual DbSet<Groups> Groups { get; set; }
        public virtual DbSet<Provinces> Provinces { get; set; }
        public virtual DbSet<Sessions> Sessions { get; set; }
        public virtual DbSet<Shops> Shops { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=.;Database=CheckInApp;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Bookings>(entity =>
            {
                entity.Property(e => e.Created).HasColumnType("datetime");

                entity.Property(e => e.EmployeeCode)
                    .HasMaxLength(100)
                    .IsFixedLength();

                entity.Property(e => e.EmployeeName).HasMaxLength(200);

                entity.HasOne(d => d.Session)
                    .WithMany(p => p.Bookings)
                    .HasForeignKey(d => d.SessionId)
                    .HasConstraintName("FK_Bookings_Sessions");

                entity.HasOne(d => d.Shop)
                    .WithMany(p => p.Bookings)
                    .HasForeignKey(d => d.ShopId)
                    .HasConstraintName("FK_Bookings_Shops");
            });

            modelBuilder.Entity<GroupSessions>(entity =>
            {
                entity.Property(e => e.LinkGroup).HasMaxLength(500);

                entity.HasOne(d => d.Group)
                    .WithMany(p => p.GroupSessions)
                    .HasForeignKey(d => d.GroupId)
                    .HasConstraintName("FK_GroupStores_Stores");

                entity.HasOne(d => d.Session)
                    .WithMany(p => p.GroupSessions)
                    .HasForeignKey(d => d.SessionId)
                    .HasConstraintName("FK_GroupStores_Sessions");
            });

            modelBuilder.Entity<Groups>(entity =>
            {
                entity.Property(e => e.Code)
                    .HasMaxLength(20)
                    .IsFixedLength();

                entity.Property(e => e.Name).HasMaxLength(200);
            });

            modelBuilder.Entity<Provinces>(entity =>
            {
                entity.Property(e => e.Code)
                    .HasMaxLength(50)
                    .IsFixedLength();

                entity.Property(e => e.Name).HasMaxLength(200);
            });

            modelBuilder.Entity<Sessions>(entity =>
            {
                entity.Property(e => e.Date).HasColumnType("datetime");

                entity.Property(e => e.Name).HasMaxLength(200);

                entity.Property(e => e.Time)
                    .HasMaxLength(2)
                    .IsFixedLength();

                entity.HasOne(d => d.Province)
                    .WithMany(p => p.Sessions)
                    .HasForeignKey(d => d.ProvinceId)
                    .HasConstraintName("FK_Sessions_Provinces");
            });

            modelBuilder.Entity<Shops>(entity =>
            {
                entity.Property(e => e.Name).HasMaxLength(200);

                entity.HasOne(d => d.Group)
                    .WithMany(p => p.Shops)
                    .HasForeignKey(d => d.GroupId)
                    .HasConstraintName("FK_Shops_Stores");
            });
            // Identity
            //modelBuilder.Entity<IdentityUser<Guid>>().ToTable("Users");
            //modelBuilder.Entity<IdentityUserLogin<Guid>>().ToTable("UserLogins").HasKey(x => x.UserId);
            //modelBuilder.Entity<IdentityUserRole<Guid>>().ToTable("UserRoles").HasKey(x => new { x.UserId, x.RoleId });

            //modelBuilder.Entity<IdentityUserClaim<Guid>>().ToTable("UserClaims");
            //modelBuilder.Entity<IdentityUserToken<Guid>>().ToTable("UserTokens").HasKey(x => x.UserId);
            //modelBuilder.Entity<IdentityRoleClaim<Guid>>().ToTable("RoleClaims");
            //OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
