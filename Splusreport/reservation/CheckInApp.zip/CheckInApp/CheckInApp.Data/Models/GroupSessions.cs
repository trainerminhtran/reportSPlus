﻿using System;
using System.Collections.Generic;

namespace CheckInApp.Data.Models
{
    public partial class GroupSessions
    {
        public int Id { get; set; }
        public int? SessionId { get; set; }
        public int? GroupId { get; set; }
        public string LinkGroup { get; set; }
        public string Prize { get; set; }
        public string Address { get; set; }

        public virtual Groups Group { get; set; }
        public virtual Sessions Session { get; set; }
    }
}
