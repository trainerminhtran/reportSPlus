﻿using System;
using System.Collections.Generic;

namespace CheckInApp.Data.Models
{
    public partial class Bookings
    {
        public int Id { get; set; }
        public int GroupId {get;set;}
        public int? SessionId { get; set; }
        public string EmployeeCode { get; set; }
        public string EmployeeName { get; set; }
        public int? ShopId { get; set; }
        public DateTime? Created { get; set; }

        public virtual Sessions Session { get; set; }
        public virtual Shops Shop { get; set; }
        public virtual Groups Group { get; set; }
    }
}
