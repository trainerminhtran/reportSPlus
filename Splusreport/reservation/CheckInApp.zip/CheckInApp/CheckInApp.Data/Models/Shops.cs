﻿using System;
using System.Collections.Generic;

namespace CheckInApp.Data.Models
{
    public partial class Shops
    {
        public Shops()
        {
            Bookings = new HashSet<Bookings>();
        }

        public int Id { get; set; }
        public int? GroupId { get; set; }
        public string Name { get; set; }

        public virtual Groups Group { get; set; }
        public virtual ICollection<Bookings> Bookings { get; set; }
    }
}
